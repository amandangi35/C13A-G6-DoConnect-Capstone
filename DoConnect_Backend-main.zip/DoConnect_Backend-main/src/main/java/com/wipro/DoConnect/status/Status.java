package com.wipro.DoConnect.status;

public enum Status {
    POSTED, APPROVED,
    ;
}
